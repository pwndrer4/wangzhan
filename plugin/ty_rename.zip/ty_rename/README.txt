-README-


使用时，请将该文件设置成为可读可写(777)
ty_rename/route/setting.txt

-WHY
