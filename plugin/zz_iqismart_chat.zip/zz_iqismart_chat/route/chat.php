<?php

!defined('DEBUG') AND exit('Forbidden');
 

include _include(APP_PATH.'plugin/zz_iqismart_chat/htm/chat.htm');
?>