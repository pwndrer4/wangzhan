<?php

!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	
	$kv = kv_get('iqismart_chat_setting');
 
					
	$input['roomname'] = form_text('roomname', $kv['roomname']);
 
	include _include(APP_PATH.'plugin/zz_iqismart_chat/setting.htm');
	
} else {

	$roomname = param('roomname', '');
	
  	if(empty(roomname)){
    	message(0, '房间名称不能为空');
    }else{
    	$kv = array();
        $kv['roomname'] = $roomname; 
        kv_set('iqismart_chat_setting', $kv);

        message(0, '修改成功');
    }
	
	
}
	
?>