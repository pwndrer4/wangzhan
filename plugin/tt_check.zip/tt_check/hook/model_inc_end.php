include _include(APP_PATH.'plugin/tt_check/model/check.func.php');
