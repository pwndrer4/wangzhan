<?php exit;
$rs = check_reg_or_not();
if($rs) check_set_user_check($r,'0');
?>