case 'check_thread': include APP_PATH.'plugin/tt_check/admin_thread.php'; break;
case 'check_post': include APP_PATH.'plugin/tt_check/admin_post.php'; break;
case 'check_user': include APP_PATH.'plugin/tt_check/admin_user.php'; break;
case 'check_uthread': include APP_PATH.'plugin/tt_check/admin_thread.php'; break;
case 'check_upost': include APP_PATH.'plugin/tt_check/admin_post.php'; break;
case 'check_uuser': include APP_PATH.'plugin/tt_check/admin_user.php'; break;
case 'check_recycle': include APP_PATH.'plugin/tt_check/admin_recycle.php'; break;