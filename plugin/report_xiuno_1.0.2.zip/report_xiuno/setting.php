<?php
!defined('DEBUG') AND exit('Access Denied.');
include _include(APP_PATH.'plugin/report_xiuno/setting.htm');
?>