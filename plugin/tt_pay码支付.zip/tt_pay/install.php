<?php
!defined('DEBUG') AND exit('Forbidden');
$settings=array('wx'=>'1','ali'=>'1','min'=>'1000');
setting_set('tt_pay',$settings);
?>