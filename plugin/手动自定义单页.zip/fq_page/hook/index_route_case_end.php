case 'hello': include APP_PATH.'plugin/fq_page/hook/hello.php'; break;
case 'hello2': include APP_PATH.'plugin/fq_page/hook/hello2.php'; break;