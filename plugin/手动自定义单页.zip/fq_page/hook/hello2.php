<?php include _include(APP_PATH.'view/htm/header.inc.htm');?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>单页2</title>
</head>
单页内容2
<body>
</body>
</html>


<?php include _include(APP_PATH.'view/htm/footer.inc.htm');?>
