<?php

/*
    Xiuno BBS 4.0 大白插件
    http://www.huux.cc
 */

!defined('DEBUG') AND exit('Forbidden');

// 同类插件互相禁用，禁用百度编辑器
plugin_unstall('xn_umeditor');

?>