?php
message(0, 'Hello, Plugin');
?>