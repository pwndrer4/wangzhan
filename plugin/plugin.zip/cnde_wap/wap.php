<?php if(empty($uid)) { ?>
<script type="text/javascript">
if(/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
    window.location.href = "?user-create.htm";
} else {
   window.location.href = "?thread-create-0.htm";
}
</script>
<?php } else { ?>
<script type="text/javascript">
if(/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
    window.location.href = "?thread-create-0.htm";
} else {
   window.location.href = "?thread-create-0.htm";
}
</script>
<?php } ?>


<section class="_135editor" style="border: 0px none; padding: 0px;">
    <section style="border: 0px; text-align: center; box-sizing: border-box; padding: 0px;">
        <section style="display: inline-block; box-sizing: border-box; color: inherit;">
            <section class="135brush" data-brushtype="text" style="margin: 0.2em 0px 0px; padding: 0px 0.5em 5px; max-width: 100%; color: #757576; font-size: 1.8em; line-height: 1; border-bottom-width: 1px; border-bottom-style: solid; border-color: #757576;">
                <span style="border-color:#757576; color:#953734; font-size:18px">大鹏新区</span>
            </section>
            <section class="135brush" data-brushtype="text" style="margin: 5px 1em; font-size: 1em; line-height: 1; color: #757576; box-sizing: border-box; border-color: #757576;">
                <span style="color: #333333; font-family: arial, 宋体, sans-serif; font-size: 12px;">Dapeng New District</span>
            </section>
        </section>
    </section>
</section>
<section data-id="12657" class="_135editor" style="border: 0px none;">
    <section class="_135editor" style="border: 0px none; padding: 0px;">
        <section style="border: 0px #ff8124; margin: 2em 1em 1em; padding: 0px;">
            <section style="line-height: 1.4; text-align: left; margin-right: 10px;">
                <section style="border-style: solid; -webkit-border-image: url(&quot;http://mpt.135editor.com/mmbiz/cZV2hRpuAPiaXAGReq0PiaE33xf7P0eJF6P6OAxswYk1Uh3ewvZjwgFSj5cbmiasWbfiaSfHWgQrgqgaVq7YgetVAg/0&quot;) 28 fill; border-width: 28px; margin-top: 1em; text-decoration: none; line-height: 1.4; text-align: left;">
                    <p class="135brush" style="text-align: center;">
                        <span style="color:#595959"><span style="font-size: 24px;"></span></span>
                    </p>
                    <p>
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color: #ff0000;">大鹏新区是深圳龙岗区的一个功能新区，成立于2011年12月30日，位于深圳东南部，三面环海，东临大亚湾，与惠州接壤，西抱大鹏湾，遥望香港新界，是粤港澳大湾区的重要节点。辖区面积600平方公里，其中陆域面积295平方公里，约占深圳市六分之一，海域面积305平方公里，约占深圳市四分之一，海岸线长133.22公里，约占全市的二分之一。共有28座水库（含2座市管水库），五个一级水源保护区水库水质为优，其中四个达到二级。下辖葵涌、大鹏、南澳三个办事处，25个社区，常住人口近20万，户籍人口3.9万。</span>
                    </p>
                    <p>
                        大鹏新区有深圳大鹏半岛国家地质公园、龙岩古寺、赖恩爵将军第、刘起龙将军墓、福田世居、长安世居、坝光村等景点
                    </p>
                    <p style="line-height: 1.75em;">
                        <span style=";color:#595959;color: #333333; font-family: arial, 宋体, sans-serif; font-size: 14px; text-indent: 28px;">&nbsp; &nbsp; &nbsp; &nbsp;截至2018年，大鹏新区下辖下辖葵涌、大鹏、南澳三个办事处，25个社区；其中葵涌办事处辖9个社区：葵新社区、葵丰社区、三溪社区、高源社区、土洋社区、官湖社区、溪涌社区、坝光社区、葵涌社区；大鹏办事处辖7个社区：王母社区、下沙社区、鹏城社区、水头社区、布新社区、岭澳社区、大鹏社区；南澳办事处辖9个社区：南澳社区、南隆社区、南渔社区、东涌社区、东渔社区、东山社区、西涌社区、新大社区、水头沙社区。</span>
                    </p>
                    <p class="135brush" style="text-align: center;">
                        <span style="color:#595959"><span style="font-size: 24px;"></span></span>
                    </p>
                </section>
            </section>
        </section>
    </section>
</section>

