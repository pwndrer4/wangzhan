
include _include(APP_PATH.'plugin/xn_ipaccess/ipaccess.func.php');