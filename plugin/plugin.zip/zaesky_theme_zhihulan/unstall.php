<?php

/*
	Xiuno BBS 4.0 大白主题
*/

!defined('DEBUG') AND exit('Forbidden');


?>