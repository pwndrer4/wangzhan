param("rob-anonymous") == 'on' ? $rob_anonymous = true : $rob_anonymous = false;
$arr['rob_anonymous'] = $rob_anonymous;