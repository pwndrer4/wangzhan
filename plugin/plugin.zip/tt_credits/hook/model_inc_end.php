include _include(APP_PATH.'plugin/tt_credits/model/credits.func.php');
