<?php

!defined('DEBUG') AND exit('Access Denied.');

http_location(url('forum'));

?>