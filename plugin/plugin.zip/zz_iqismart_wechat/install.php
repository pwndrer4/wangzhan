<?php

/*
	邮件提醒插件安装文件
	QQ:1778871523
	qq群:558951704
*/

!defined('DEBUG') AND exit('Forbidden');
 
// 初始化参数数据
$kv = kv_get('wechat_notice');
if (!$kv) {
    $kv = array(
        'template_id' => 'TUl8C_xUz9MDB5zMRSdaP65KpKVh_qYadP-KKeE5Eeo', 
        'reply_content_field' => 'first',
        'thread_title_field' => 'keyword1',
        'reply_nick_field' => 'keyword2',//端口
        'reply_time_field' => "keyword3",
              
    );
    kv_set('wechat_notice', $kv);
}

//数据库增加一个字段
$tablepre = $db->tablepre;
$sql = "ALTER TABLE {$tablepre}user ADD COLUMN wechat_notice TINYINT NOT NULL DEFAULT 1";
$r = db_exec($sql);

?>