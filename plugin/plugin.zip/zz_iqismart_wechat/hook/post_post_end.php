include _include(APP_PATH . 'plugin/skiy_wx_login/model/wechat.class.php');
include _include(APP_PATH . 'plugin/skiy_wx_login/model/wx_login.func.php');


function getplaintextintrofromhtml($html, $numchars) {
		$html = preg_replace('~<([a-z]+?)\s+?.*?>~i','<$1>',$html); 
  $html = strip_tags($html);
  $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
  $html_len = mb_strlen($html,'UTF-8');
  $html = mb_substr($html, 0, $numchars, 'UTF-8');
  if($html_len>$numchars){
  $html .= "…";
  $html = str_replace('"',"",$html);  
  }
  return $html;
}

//获取帖子标题
$thread_msg=thread_read($tid);
$thread_title=$thread_msg['subject'];
$thread_uid=$thread_msg['uid'];//楼主uid
//获取楼主用户名
$thread_user_msg=user_read($thread_uid);
$user_name=$thread_user_msg['username'];
$user_email=$thread_user_msg['email'];
//获取回帖者用户名
$reply_user_msg=user_read($uid);
$reply_nick=$reply_user_msg['username'];
//回复内容
$reply_content=getplaintextintrofromhtml($message,150);
//回复时间
$reply_time=date("Y/m/d H:i:s",$time);

//帖子链接
$thread_url=$_SERVER['SERVER_NAME'].'/'.url("thread-".$tid);

//判断是否为引用
if($quotepid !=0){
	$quotepost_msg=user_read($quotepost['uid']);
	$user_email=$quotepost_msg['email'];
	$user_name=$quotepost_msg['username'];
	
	
} 
//wechat

$kv = kv_get('wechat_notice');
if (!$kv) {
    $kv = array(
        'template_id' => 'TUl8C_xUz9MDB5zMRSdaP65KpKVh_qYadP-KKeE5Eeo', 
        'reply_content_field' => 'first',
        'thread_title_field' => 'keyword1',
        'reply_nick_field' => 'keyword2',//端口
        'reply_time_field' => "keyword3",
              
    );
    kv_set('wechat_notice', $kv);
}
$template_id = $kv['template_id'];
 
$reply_content_field = $kv['reply_content_field'];
$thread_title_field = $kv['thread_title_field'];
$reply_nick_field = $kv['reply_nick_field'];
$reply_time_field = $kv['reply_time_field'];

if($thread_user_msg['wechat_notice']){
  $bind = wx_had_bind_user_by_uid($thread_user_msg['uid']);
  if($bind){
     $wxlogin = kv_get('skiy_wx_login');
     $wx_config = [
                 'appid' => $wxlogin['appid'],
                 'appsecret' => $wxlogin['appsecret'],
             ];
     $wechat = new Wechat($wx_config);
     $openid = $bind['openid'];
     /*
     {{first.DATA}}
     问题：{{keyword1.DATA}}
     回答人：{{keyword2.DATA}}
     时间：{{keyword3.DATA}}
     {{remark.DATA}}

     */
     $data = '{
            "touser":"'.$openid.'",
            "template_id":"'.$template_id.'",
            "url":"'.$thread_url.'",
            "topcolor":"#FF0000",
            "data":{
            "'.$reply_content_field.'": {
            "value":"'.$reply_content.'",
            "color":"#173177"
            },
            "'.$thread_title_field.'":{
            "value":"《'.$thread_title.'》",
            "color":"#173177"
            },
            "'.$reply_nick_field.'":{
            "value":"'.$reply_nick.'",
            "color":"#173177"
            },
            "'.$reply_time_field.'":{
            "value":"'.$reply_time.'",
            "color":"#173177"
            },
            "remark":{
                      "value":"",
                      "color":"#173177"
                      }
            }
            }';
		 
     $wechat->sendTemplateMessage($data);

  }
}
//引用
if($quotepid !=0){
	if($quotepost_msg['wechat_notice']){
      $bind = wx_had_bind_user_by_uid($quotepost_msg['uid']);
      if($bind){
         $wxlogin = kv_get('skiy_wx_login');
         $wx_config = [
                     'appid' => $wxlogin['appid'],
                     'appsecret' => $wxlogin['appsecret'],
                 ];
         $wechat = new Wechat($wx_config);
         $openid = $bind['openid'];
         /*
         {{first.DATA}}
         问题：{{keyword1.DATA}}
         回答人：{{keyword2.DATA}}
         时间：{{keyword3.DATA}}
         {{remark.DATA}}

         */
         $data = '{
            "touser":"'.$openid.'",
            "template_id":"'.$template_id.'",
            "url":"'.$thread_url.'",
            "topcolor":"#FF0000",
            "data":{
            "'.$reply_content_field.'": {
            "value":"'.$reply_content.'",
            "color":"#173177"
            },
            "'.$thread_title_field.'":{
            "value":"《'.$thread_title.'》",
            "color":"#173177"
            },
            "'.$reply_nick_field.'":{
            "value":"'.$reply_nick.'",
            "color":"#173177"
            },
            "'.$reply_time_field.'":{
            "value":"'.$reply_time.'",
            "color":"#173177"
            },
            "remark":{
                      "value":"",
                      "color":"#173177"
                      }
            }
            }';

         $wechat->sendTemplateMessage($data);

      }
  }
}
//wechat end

 
 
  