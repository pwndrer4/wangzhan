

<?php exit;
	case 'baidutui': include _include(APP_PATH.'plugin/aitu_baidutui/route/baidutui.php'); break;
?>