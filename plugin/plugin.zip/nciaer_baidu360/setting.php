<?php
!defined('DEBUG') AND exit('Access Denied.');
if ($method == 'GET') {
    $pconfig = setting_get('nciaer_baidu360');
    $hash = $pconfig['hash'];
    $status_baidu = $pconfig['status_baidu'];
    $status_360 = $pconfig['status_360'];
    include _include(APP_PATH . 'plugin/nciaer_baidu360/setting.htm');
} else {
    $hash = param('hash', '');
    $status_baidu = param('status_baidu', 0);
    $status_360 = param('status_360', 0);
    $pconfig = array();
    $pconfig['hash'] = $hash;
    $pconfig['status_baidu'] = $status_baidu;
    $pconfig['status_360'] = $status_360;
    setting_set('nciaer_baidu360', $pconfig);
    message(0, '提交成功！');
}
