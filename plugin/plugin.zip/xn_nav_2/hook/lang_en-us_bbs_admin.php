	'nav_2_on'=>'Enable secondary level navigation',
	'nav_2_bbs_on'=>'Enable BBS Link in navigation',
	'nav_2_forum_list_pc_on'=>'Show forum list on secondary navigation in PC',
	'nav_2_forum_list_mobile_on'=>'Show forum list on secondary navigation in Mobile',