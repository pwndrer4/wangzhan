<?php

/*
	Xiuno BBS 4.0 大白插件市场
*/

!defined('DEBUG') AND exit('Forbidden');

// 删除数据就没有了
setting_delete('huux_plugin');



?>