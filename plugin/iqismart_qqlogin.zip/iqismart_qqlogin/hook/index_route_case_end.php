
		case 'qq_login':		include _include(APP_PATH.'plugin/iqismart_qqlogin/route/qq_login.php'); 	break;