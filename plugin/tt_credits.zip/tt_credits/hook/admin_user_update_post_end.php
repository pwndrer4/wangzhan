if($_gid>=100){
    user_update_group($_uid);
}