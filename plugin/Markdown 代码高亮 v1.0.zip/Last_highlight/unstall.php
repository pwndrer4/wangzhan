<?php

/*  Xiuno BBS 4.0 代码高亮 
	主题 折叠 其他
*/

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('Last_highlight');

?>