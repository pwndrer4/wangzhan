<?php

/**
 * 卸载免签微信接入
 * style <364337403@qq.com>
 * https://www.iqismart.com
 */

!defined('DEBUG') AND exit('Forbidden');
 
