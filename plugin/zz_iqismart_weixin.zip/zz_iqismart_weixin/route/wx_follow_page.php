<?php

include _include(APP_PATH.'plugin/zz_iqismart_weixin/view/htm/follow.htm');

?>