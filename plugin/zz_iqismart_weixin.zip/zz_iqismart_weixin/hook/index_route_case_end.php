case 'wx_login': include APP_PATH.'plugin/zz_iqismart_weixin/route/wx_login.php'; break;
case 'wx_follow_page': include APP_PATH.'plugin/zz_iqismart_weixin/route/wx_follow_page.php'; break;
