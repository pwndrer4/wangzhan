<?php
return array(
    'name' => '贤弟云支付-免签约支付',
    'user' => 'XianD',
    'icon' => '',
    'mess' => '',
    'version' => '1.0',
);