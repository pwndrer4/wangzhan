<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
{"name":"XianD_Pay","partner":"","key":"","proportion":"100"}