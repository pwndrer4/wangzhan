<?php
/**
 * Author: XianD
 * Date: 2018/6/26
 * Time: 0:22
 */
return [
    'Action/My.php'=> [
        'view/My'=>'view/My_modify'
    ]
];