<?php exit;
$offer_num=0;
$input['offer_status'] = form_radio_yes_no('offer_status', 0);
?>