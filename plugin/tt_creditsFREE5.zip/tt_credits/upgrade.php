<?php !defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;


?>