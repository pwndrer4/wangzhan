$input['credits'] = form_text('credits', $_user['credits']);
$input['golds'] = form_text('golds', $_user['golds']);
$input['rmbs'] = form_text('rmbs', $_user['rmbs']);