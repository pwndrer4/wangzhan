
	include _include(APP_PATH.'plugin/tt_stamp/model/thread_stamp.func.php');
